/OSLAB/gxemul -E testmips -C R3000 -M 64 vmlinux
