#include "lib.h"
#include "printf.h"

void umain()
{
	writef("Hello world!");
}
