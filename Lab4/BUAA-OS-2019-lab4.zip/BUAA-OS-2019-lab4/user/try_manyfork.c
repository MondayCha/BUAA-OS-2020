#include "lib.h"

int a;

void umain()
{
	if(fork()==0)
		if(fork()==0)
			if(fork()==0)
				if(fork()==0)
					if(fork()==0)
						if(fork()==0)
							if(fork()==0)
								if(fork()==0)
									if(fork()==0)
										if(fork()==0)
											if(fork()==0)
												if(fork()==0)
													if(fork()==0)
														if(fork()==0)
															if(fork()==0)
																if(fork()==0)
																	if(fork()==0)
																		if(fork()==0)
																			if(fork()==0)
																				if(fork()==0)
																					if(fork()==0)
																						if(fork()==0)
																							if(fork()==0)
																								if(fork()==0)
																									if(fork()==0)
																										if(fork()==0)
																											if(fork()==0)
																												if(fork()==0)
																													if(fork()==0)
																														if(fork()==0)
																														{}
}
