#include "lib.h"
#include "printf.h"

void umain()
{
	while(1)
	{
		int i;
		int b = 0;
		writef("2 ");
		for(i = 1; i <= 1000; i++)
		{
			b++;
			// to delay
		}
	}
}
