#include "../drivers/gxconsole/dev_cons.h"
#include <mmu.h>
#include <env.h>
#include <printf.h>
#include <pmap.h>
#include <sched.h>

extern char *KERNEL_SP;
extern struct Env *curenv;

/* Overview:
 * 	This function is used to print a character on screen.
 * 
 * Pre-Condition:
 * 	`c` is the character you want to print.
 */
void sys_putchar(int sysno, int c, int a2, int a3, int a4, int a5)
{
	printcharc((char) c);
	return ;
}

/* Overview:
 * 	This function enables you to copy content of `srcaddr` to `destaddr`.
 *
 * Pre-Condition:
 * 	`destaddr` and `srcaddr` can't be NULL. Also, the `srcaddr` area 
 * 	shouldn't overlap the `destaddr`, otherwise the behavior of this 
 * 	function is undefined.
 *
 * Post-Condition:
 * 	the content of `destaddr` area(from `destaddr` to `destaddr`+`len`) will
 * be same as that of `srcaddr` area.
 */
void *memcpy(void *destaddr, void const *srcaddr, u_int len)
{
	char *dest = destaddr;
	char const *src = srcaddr;

	while (len-- > 0) {
		*dest++ = *src++;
	}

	return destaddr;
}

/* Overview:
 *	This function provides the environment id of current process.
 *
 * Post-Condition:
 * 	return the current environment id
 */
u_int sys_getenvid(void)
{
	return curenv->env_id;
}

/* Overview:
 *	This function enables the current process to give up CPU.
 *	实现用户进程对CPU 的放弃
 *
 * Post-Condition:
 * 	Deschedule current environment. This function will never return.
 */
/*** exercise 4.6 ***/
void sys_yield(void)
{
	struct Trapframe *src = (struct Trapframe*)(KERNEL_SP - sizeof(struct Trapframe));
	struct Trapframe *dst = (struct Trapframe*)(TIMESTACK - sizeof(struct Trapframe));
    bcopy((void*)src, (void*)dst, sizeof(struct Trapframe));
	// 从KERNAL_SP顶部复制栈帧到TIMESTACK中

	// 调用sched_yield()
	sched_yield();
	// 在sched_yield()最后调用到env_run()的时候
	// 会从TIMESTACK取出栈帧，而当前栈帧是保存在KERNEL_SP里面的
}

/* Overview:
 * 	This function is used to destroy the current environment.
 *
 * Pre-Condition:
 * 	The parameter `envid` must be the environment id of a 
 * process, which is either a child of the caller of this function 
 * or the caller itself.
 *
 * Post-Condition:
 * 	Return 0 on success, < 0 when error occurs.
 */
int sys_env_destroy(int sysno, u_int envid)
{
	/*
		printf("[%08x] exiting gracefully\n", curenv->env_id);
		env_destroy(curenv);
	*/
	int r;
	struct Env *e;

	if ((r = envid2env(envid, &e, 1)) < 0) {
		return r;
	}

	printf("[%08x] destroying %08x\n", curenv->env_id, e->env_id);
	env_destroy(e);
	return 0;
}

/* Overview:
 * 	Set envid's pagefault handler entry point and exception stack.
 * 	这个函数的意义是为envid所对应的进程控制块设置相应的缺页处理函数
 * 
 * Pre-Condition:
 * 	xstacktop points one byte past exception stack.
 *
 * Post-Condition:
 * 	The envid's pagefault handler will be set to `func` and its
 * 	exception stack will be set to `xstacktop`.
 * 	Returns 0 on success, < 0 on error.
 */
/*** exercise 4.12 ***/
int sys_set_pgfault_handler(int sysno, u_int envid, u_int func, u_int xstacktop)
{
	// Your code here.
	struct Env *env;
	int ret;

	ret = envid2env(envid, &env, 0);
	if (ret < 0)
		return ret;

	// 设置缺页时的处理函数func
	env->env_pgfault_handler = func;
	env->env_xstacktop = xstacktop;

	return 0;
	//	panic("sys_set_pgfault_handler not implemented");
}

/* Overview:
 * 	Allocate a page of memory and map it at 'va' with permission
 * 'perm' in the address space of 'envid'.
 *
 * 	If a page is already mapped at 'va', that page is unmapped as a
 * side-effect.
 * 如果va处已经有物理页，则将旧的物理页顶掉（page_insert的功能）
 * 
 * Pre-Condition:
 * perm -- PTE_V is required,
 *         PTE_COW is not allowed(return -E_INVAL),
 *         other bits are optional.
 * 写时复制关闭（PTE_COW）；检测有效位（PTE_V）
 *
 * Post-Condition:
 * Return 0 on success, < 0 on error
 *	- va must be < UTOP
 *	va必须小于UTOP，大于等于0
 *	- env may modify its own address space or the address space of its children
 *	进程只可以修改自己的、或者是子进程的地址
 */
/*** exercise 4.3 ***/
// 函数的主要功能是分配内存
int sys_mem_alloc(int sysno, u_int envid, u_int va, u_int perm)
{
	// Your code here.
	struct Env *env;
	struct Page *ppage;
	int ret;
	ret = 0;

	// 2020-05-10
	// va必须小于UTOP，大于等于0
	if ((va >= UTOP) || (va < 0))
		return -E_UNSPECIFIED;

	// 写时复制关闭（PTE_COW）；检测有效位（PTE_V）
	// 检查标记位是否有PTE_COW ，如果有，报错
	// 检查所需要添加的标记位是否带有PTE_V,如果没有，报错
	if((perm & PTE_COW) || !(perm & PTE_V))
		return -E_INVAL;

	// 用envid2env找到需要被分配物理页的进程
	ret = envid2env(envid, &env, 1); 	// 试一下设置为1会怎样,进程只可以修改自己的、或者是子进程的地址
	if (ret < 0)
		return ret;

	// alloc一个物理页
	ret = page_alloc(&ppage);
	if (ret < 0)
		return ret;

	// 将物理页插入进程的二级页表中
	// 利用page_insert() 去把这一页插入到env对应的内存空间中的va处，并且设置权限位为perm
	ret = page_insert(env->env_pgdir, ppage, va, perm);
	if (ret < 0)
		return ret;

	// 如果成功执行，返回0
	return 0;
}

/* Overview:
 * 	Map the page of memory at 'srcva' in srcid's address space
 * at 'dstva' in dstid's address space with permission 'perm'.
 * Perm has the same restrictions as in sys_mem_alloc.
 * (Probably we should add a restriction that you can't go from
 * non-writable to writable?)
 * 将源进程地址空间中的相应内存映射到目标进程的相应地址空间的相应虚拟内存中
 * 把srcid对应的进程中srcva地址的一页内存给共享到dstid对应的进程中dstva的位置
 * 此时两者共享着一页物理内存
 *
 * Post-Condition:
 * 	Return 0 on success, < 0 on error.
 *
 * Note:
 * 	Cannot access pages above UTOP.
 * 	只能获取UTOP之下的物理页
 */
/*** exercise 4.4 ***/
int sys_mem_map(int sysno, u_int srcid, u_int srcva, u_int dstid, u_int dstva,
				u_int perm)
{
	int ret;
	u_int round_srcva, round_dstva;
	struct Env *srcenv;
	struct Env *dstenv;
	struct Page *ppage;
	Pte *ppte = NULL; 		// 2020-4-28 ADD

	ppage = NULL;
	ret = 0;

	// 先把srcva和dstva都通过ROUNDDOWN() 进行按页对齐
	round_srcva = ROUNDDOWN(srcva, BY2PG);
	round_dstva = ROUNDDOWN(dstva, BY2PG);

    //your code here
	
	// 检查srcva和dstva，要求均在 [0,UTOP) 范围内
	if (dstva >= UTOP || dstva < 0 || srcva >= UTOP || srcva < 0)
		return -E_UNSPECIFIED;

	// 检查参数所提供的perm,要求必须包含PTE_V
	if (!(perm & PTE_V))
		return -E_INVAL;

	// 通过envid2env获得srcid和dstid对应的进程控制块
	ret = envid2env(srcid, &srcenv, 0);
	if (ret < 0)
		return ret;

	ret = envid2env(dstid, &dstenv, 0);
	if (ret < 0)
		return ret;

	// 通过page_lookup() 找出srcva在源进程中对应的页
	ppage = page_lookup(srcenv->env_pgdir, round_srcva, &ppte);
	if (ppage == NULL || (!(*ppte & PTE_R) && (perm & PTE_R))) 	// 企图从不可写映射到可写,返回错误
		return -E_INVAL;

	// 把找到的这一页通过page_insert() 给插入到目的进程中的dstva处
	ret = page_insert(dstenv->env_pgdir, ppage, round_dstva, perm);
	if (ret < 0)
		return ret;

	return ret; 		// ret = 0
}

/* Overview:
 * 	Unmap the page of memory at 'va' in the address space of 'envid'
 * (if no page is mapped, the function silently succeeds)
 * 解除某个进程地址空间虚拟内存和物理内存之间的映射关系
 *
 * Post-Condition:
 * 	Return 0 on success, < 0 on error.
 *
 * Cannot unmap pages above UTOP.
 * 只能获取UTOP之下的物理页
 */
/*** exercise 4.5 ***/
int sys_mem_unmap(int sysno, u_int envid, u_int va)
{
	// Your code here.
	int ret;
	struct Env *env;

	if (va >= UTOP || va < 0)
		return -E_INVAL;

	// 通过envid找到对应的进程控制块
	ret = envid2env(envid, &env, 0); 		// need 0
	if (ret < 0)
		return ret;

	// 利用page_remove() 把这一页给移除,succeeds
	page_remove(env->env_pgdir, va);

	return ret;
	//	panic("sys_mem_unmap not implemented");
}

/* Overview:
 * 	Allocate a new environment.
 * 	这个函数负责创建一个新的进程
 *
 * 	在fork 的实现中，
 * 	我们是通过判断syscall_env_alloc 的返回值来决定fork 的返回值以及后续动作
 *
 * Pre-Condition:
 * The new child is left as env_alloc created it, except that
 * status is set to ENV_NOT_RUNNABLE and the register set is copied
 * from the current environment.
 *
 * Post-Condition:
 * 	In the child, the register set is tweaked so sys_env_alloc returns 0.
 * 	Returns envid of new environment, or < 0 on error.
 */
/*** exercise 4.8 ***/
int sys_env_alloc(void)
{
	// Your code here.
	int r;
	struct Env *e;

	// 先利用env_alloc() 申请一个空的进程控制块
	r = env_alloc(&e, curenv->env_id);
	if (r < 0)
		return r; 						// 如果分配失败

	// 把这个新进程设置为不可运行
	e->env_status = ENV_NOT_RUNNABLE;	
	
	// 由于现在notr，从KERNEL_SP拷贝父进程的原始状态,复制当前运行现场（Trapframe）到子进程中
	bcopy((void *)KERNEL_SP - sizeof(struct Trapframe), (void *)&(e->env_tf), sizeof(struct Trapframe));

	// 这些信息初始化的值应该是依赖于父类（提示：env_pri）
	e->env_pri = curenv->env_pri;

	// 子进程的程序计数器应该被设置为syscall_env_alloc 返回后的地址，
	// 也就是它陷入异常地址的下一行指令的地址epc，这个值已经存在于Trapframe 中
	e->env_tf.pc = e->env_tf.cp0_epc;

	////////////////////////////////////////////////////////////////
	//这个系统调用本身是需要一个返回值的（这个返回过程只会影响到父进程）
	// 对于子进程则需要对它的运行现场Trapframe 进行一个修改

	// 2号寄存器是返回值寄存器，子进程返回值是0
	e->env_tf.regs[2] = 0;

	// 这个过程给fork函数返回值是子进程的id
	return e->env_id;
	//	panic("sys_env_alloc not implemented");
}

/* Overview:
 * 	Set envid's env_status to status.
 *
 * Pre-Condition:
 * 	status should be one of `ENV_RUNNABLE`, `ENV_NOT_RUNNABLE` and
 * `ENV_FREE`. Otherwise return -E_INVAL.
 * 
 * Post-Condition:
 * 	Returns 0 on success, < 0 on error.
 * 	Return -E_INVAL if status is not a valid status for an environment.
 * 	The status of environment will be set to `status` on success.
 */
/*** exercise 4.14 ***/
int sys_set_env_status(int sysno, u_int envid, u_int status)
{
	// Your code here.
	struct Env *env;
	int ret;

	if (status != ENV_RUNNABLE && status != ENV_NOT_RUNNABLE && status != ENV_FREE)
		return -E_INVAL;

	ret = envid2env(envid, &env, 0);
	if (ret < 0)
		return ret;

	env->env_status = status;

	if (status == ENV_FREE)
	{
		env_destroy(env);	
	}

	return 0;
	//	panic("sys_env_set_status not implemented");
}

/* Overview:
 * 	Set envid's trap frame to tf.
 *
 * Pre-Condition:
 * 	`tf` should be valid.
 *
 * Post-Condition:
 * 	Returns 0 on success, < 0 on error.
 * 	Return -E_INVAL if the environment cannot be manipulated.
 *
 * Note: This hasn't be used now?
 */
int sys_set_trapframe(int sysno, u_int envid, struct Trapframe *tf)
{

	return 0;
}

/* Overview:
 * 	Kernel panic with message `msg`. 
 *
 * Pre-Condition:
 * 	msg can't be NULL
 *
 * Post-Condition:
 * 	This function will make the whole system stop.
 */
void sys_panic(int sysno, char *msg)
{
	// no page_fault_mode -- we are trying to panic!
	panic("%s", TRUP(msg));
}

/* Overview:
 * 	This function enables caller to receive message from 
 * other process. To be more specific, it will flag 
 * the current process so that other process could send 
 * message to it.
 *
 * Pre-Condition:
 * 	`dstva` is valid (Note: NULL is also a valid value for `dstva`).
 * 
 * Post-Condition:
 * 	This syscall will set the current process's status to 
 * ENV_NOT_RUNNABLE, giving up cpu. 
 */
/*** exercise 4.7 ***/
void sys_ipc_recv(int sysno, u_int dstva)
{
	// 检查地址是否合法
	if (dstva >= UTOP || dstva < 0)
		return;

	curenv->env_ipc_recving = 1; 			// 表明该进程准备接受其它进程的消息了
	curenv->env_ipc_dstva = dstva; 			// 修改env_ipc_dstva
	curenv->env_status = ENV_NOT_RUNNABLE; 	// 阻塞当前进程

	sys_yield(); 							// 放弃CPU（调用相关函数重新进行调度）
}

/* Overview:
 * 	Try to send 'value' to the target env 'envid'.
 * 	用于发送消息
 *
 * 	The send fails with a return value of -E_IPC_NOT_RECV if the
 * target has not requested IPC with sys_ipc_recv.
 * 	Otherwise, the send succeeds, and the target's ipc fields are
 * updated as follows:
 *    env_ipc_recving is set to 0 to block future sends
 *    env_ipc_from is set to the sending envid
 *    env_ipc_value is set to the 'value' parameter
 * 	The target environment is marked runnable again.
 *
 * Post-Condition:
 * 	Return 0 on success, < 0 on error.
 *
 * Hint: the only function you need to call is envid2env.
 */
/*** exercise 4.7 ***/
int sys_ipc_can_send(int sysno, u_int envid, u_int value, u_int srcva,
					 u_int perm)
{

	int r;
	struct Env *e;
	struct Page *p;

	Pte *ppte;
	ppte = NULL;

	if(srcva >= UTOP || srcva < 0)
		return -E_INVAL;

	// 根据envid找到相应进程
	r = envid2env(envid, &e, 0);
	if (r < 0)
		return r;

	// 检查接收进程是否接收
	if (e->env_ipc_recving != 1)
		return -E_IPC_NOT_RECV; 		// 函数返回_E_IPC_NOT_RECV

	// 发送成功
	e->env_ipc_recving = 0; 		 	// 把目的进程的env_ipc_recving给置0，以禁止别的进程再次发送信息
	e->env_ipc_from = curenv->env_id; 	// 把目的进程的env_ipc_from置为当前进程的envid
	e->env_ipc_value = value; 			// 把目的进程的env_ipc_value置为value
	e->env_ipc_perm = perm | PTE_V; 	// 把目的进程的env_ipc_perm置为perm|PTE_V

	// 使用srcva 为0 的调用来表示不需要传递物理页面
	if (srcva > 0) 						// 需要传递物理页面
	{
		// 这里调用函数可能并不好，切换为与Lab4-extra类似的方式
		// r = sys_mem_map(sysno, curenv->env_id, srcva, envid, e->env_ipc_dstva, perm);
		p = page_lookup(curenv->env_pgdir, srcva, &ppte);
		if (p == NULL || (!(*ppte & PTE_R) && (perm & PTE_R)))
			return -E_INVAL;

		r = page_insert(e->env_pgdir, p, e->env_ipc_dstva, perm);
		if (r < 0)
			return r;
	}

	e->env_status = ENV_RUNNABLE; 		// 使其可运行(ENV_RUNNABLE)

	return 0;
}

/* Overview:
 * 	This function is used to write data to device, which is
 * 	represented by its mapped physical address.
 *	Remember to check the validity of device address (see Hint below);
 * 
 * Pre-Condition:
 *      'va' is the startting address of source data, 'len' is the
 *      length of data (in bytes), 'dev' is the physical address of
 *      the device
 * 	
 * Post-Condition:
 *      copy data from 'va' to 'dev' with length 'len'
 *      Return 0 on success.
 *	Return -E_INVAL on address error.
 *      
 * Hint: Use ummapped segment in kernel address space to perform MMIO.
 *	 Physical device address:
 *	* ---------------------------------*
 *	|   device   | start addr | length |
 *	* -----------+------------+--------*
 *	|  console   | 0x10000000 | 0x20   |
 *	|    IDE     | 0x13000000 | 0x4200 |
 *	|    rtc     | 0x15000000 | 0x200  |
 *	* ---------------------------------*
 */
int sys_write_dev(int sysno, u_int va, u_int dev, u_int len)
{
        // Your code here
}

/* Overview:
 * 	This function is used to read data from device, which is
 * 	represented by its mapped physical address.
 *	Remember to check the validity of device address (same as sys_read_dev)
 * 
 * Pre-Condition:
 *      'va' is the startting address of data buffer, 'len' is the
 *      length of data (in bytes), 'dev' is the physical address of
 *      the device
 * 
 * Post-Condition:
 *      copy data from 'dev' to 'va' with length 'len'
 *      Return 0 on success, < 0 on error
 *      
 * Hint: Use ummapped segment in kernel address space to perform MMIO.
 */
int sys_read_dev(int sysno, u_int va, u_int dev, u_int len)
{
        // Your code here
}
