ctags -R --fields=+S
