/*
 * operations on IDE disk.
 */

#include "fs.h"
#include "lib.h"
#include <mmu.h>

#define IDE_BEGIN_ADDR 		0x13000000
#define IDE_OFFSET_ADDR   	(IDE_BEGIN_ADDR + 0x0000)
#define IDE_OFFSETHI_ADDR 	(IDE_BEGIN_ADDR + 0x0008)
#define IDE_ID_ADDR       	(IDE_BEGIN_ADDR + 0x0010)
#define IDE_OP_ADDR       	(IDE_BEGIN_ADDR + 0x0020)
#define IDE_STATUS_ADDR   	(IDE_BEGIN_ADDR + 0x0030)
#define IDE_BUFFER_ADDR   	(IDE_BEGIN_ADDR + 0x4000)
#define IDE_BUFFER_SIZE 	0x0200

// Overview:
// 	read data from IDE disk. First issue a read request through
// 	disk register and then copy data from disk buffer
// 	(512 bytes, a sector) to destination array.
//
// Parameters:
//	diskno: disk number.
// 	secno: start sector number.
// 	dst: destination for data read from IDE disk.
// 	nsecs: the number of sectors to read.
//
// Post-Condition:
// 	If error occurred during read the IDE disk, panic. 
// 	
// Hint: use syscalls to access device registers and buffers
/****** Exercise 5.2 *******/
void
ide_read(u_int diskno, u_int secno, void *dst, u_int nsecs)
{
	// 0x200: the size of a sector: 512 bytes.
	int offset_begin = secno * 0x200;
	int offset_end = offset_begin + nsecs * 0x200;
	int offset = 0;

	// 定义下面三个变量
	u_int va = offset_begin + offset;
	u_char op = 0;
	u_char status = 0;

	while (va < offset_end) {
    	// Your code here
        // error occurred, then panic.

		// 利用syscall_write_dev向IDE_ID_ADDR写入diskno，
		// len设置为4（字节）。此步骤是为了选择要写入的磁盘号
		if (syscall_write_dev((u_int)&diskno, IDE_ID_ADDR, 4) < 0)
			user_panic("ide_read IDE_ID_ADDR error!\n");

		// 利用syscall_write_dev向IDE_OFFSET_ADDR写入va，
		// len设置为4（字节）。此步骤是为了选择要写入的磁盘地址（偏移）
		if (syscall_write_dev((u_int)&va, IDE_OFFSET_ADDR, 4) < 0)
			user_panic("ide_read IDE_OFFSET_ADDR error!\n");

		// 利用syscall_write_dev向IDE_OP_ADDR写入op，
		// len设置为1（字节）。此步骤是为了选择要进行的操作，
		// 在这里，我们的op=0，代表要读取
		if (syscall_write_dev((u_int)&op, IDE_OP_ADDR, 1) < 0)
			user_panic("ide_read IDE_OP_ADDR error!\n");

		// 写完上面的内容之后，正常情况下，
		// 我们所需要读取的内容应该会被送到了缓冲区内。
		// 所以我们进行如下操作
		
		status = 0;
		// 利用syscall_read_dev从IDE_STATUS_ADDR读取一个字节的内容到status
		if (syscall_read_dev((u_int)&status, IDE_STATUS_ADDR, 1) < 0)
			user_panic("ide_read IDE_STATUS_ADDR error!\n");

		// 如果上一步得到的status结果为0，代表读取失败了，panic
		if (status == 0)
			user_panic("ide_read status == 0!\n");

		// 如果结果非0，代表读取成功，则使用syscall_read_dev
		// 从IDE_BUFFER_ADDR读取IDE_BUFFER_SIZE大小的内容到dst+offset中去
		if (syscall_read_dev((u_int)(dst + offset), IDE_BUFFER_ADDR, IDE_BUFFER_SIZE) < 0)
			user_panic("ide_read IDE_BUFFER_ADDR error!\n");

		offset += IDE_BUFFER_SIZE;
		va = offset_begin + offset;
	}
}


// Overview:
// 	write data to IDE disk.
//
// Parameters:
//	diskno: disk number.
//	secno: start sector number.
// 	src: the source data to write into IDE disk.
//	nsecs: the number of sectors to write.
//
// Post-Condition:
//	If error occurred during read the IDE disk, panic.
//	
// Hint: use syscalls to access device registers and buffers
void
ide_write(u_int diskno, u_int secno, void *src, u_int nsecs)
{
    // Your code here
	int offset_begin = secno * 0x200;
	int offset_end = offset_begin + nsecs * 0x200;
	int offset = 0;

	// 定义下面三个变量
	u_int va = offset_begin + offset;
	u_char op = 1;
	u_char status = 0;

	writef("diskno: %d\n", diskno);
	
	while (va < offset_end) {
    	// Your code here
        // error occurred, then panic.

		// 利用syscall_write_dev向IDE_ID_ADDR写入diskno，
		// len设置为4（字节）。此步骤是为了选择要写入的磁盘号
		if (syscall_write_dev((u_int)&diskno, IDE_ID_ADDR, 4) < 0)
			user_panic("ide_write IDE_ID_ADDR error!\n");

		// 利用syscall_write_dev向IDE_OFFSET_ADDR写入va，
		// len设置为4（字节）。此步骤是为了选择要写入的磁盘地址（偏移）
		if (syscall_write_dev((u_int)&va, IDE_OFFSET_ADDR, 4) < 0)
			user_panic("ide_write IDE_OFFSET_ADDR error!\n");

		// 先把要写入的内容写到BUFFER里面，
		// 然后再把op=1给写到对应位置，启动ide的写入
		if (syscall_write_dev((u_int)(src + offset), IDE_BUFFER_ADDR, IDE_BUFFER_SIZE) < 0)
			user_panic("ide_write IDE_BUFFER_ADDR error!\n");

		// 利用syscall_write_dev向IDE_OP_ADDR写入op，
		// len设置为1（字节）。此步骤是为了选择要进行的操作，
		// 在这里，我们的op=1
		if (syscall_write_dev((u_int)&op, IDE_OP_ADDR, 1) < 0)
			user_panic("ide_write IDE_OP_ADDR error!\n");

		// 写完上面的内容之后，正常情况下，
		// 我们所需要读取的内容应该会被送到了缓冲区内。
		// 所以我们进行如下操作
		
		status = 0;
		// 利用syscall_read_dev从IDE_STATUS_ADDR读取一个字节的内容到status
		if (syscall_read_dev((u_int)&status, IDE_STATUS_ADDR, 1) < 0)
			user_panic("ide_write IDE_STATUS_ADDR error!\n");

		// 如果上一步得到的status结果为0，代表读取失败了，panic
		if (status == 0)
			user_panic("ide_write status == 0!\n");

		offset += IDE_BUFFER_SIZE;
		va = offset_begin + offset;
	}
}

