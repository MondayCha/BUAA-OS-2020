
#include "lib.h"

#define N 100

int space[101];
int mutex;
int full;
int empty;
int head;
int tail;

void consumer();
void producer();

void umain()
{
	mutex = syscall_init_PV_var(1);
	full = syscall_init_PV_var(0);
	empty = syscall_init_PV_var(N);
	head = 0;
	tail = 0;
	int i = fork();
	if (i == 0)
	{
		producer();
	}
	else
	{
		consumer();
	}
}

void consumer()
{
	while (1)
	{
		syscall_P(full);
		syscall_P(mutex);
		head = (head + 1) % N;
		space[head] = head;
		writef("consumer get %d\n", head);
		syscall_V(mutex);
		syscall_V(empty);
		// syscall_check_PV_value(full);
	}
}

void producer()
{
	while (1)
	{
		syscall_P(empty);
		syscall_P(mutex);
		tail = (tail + 1) % N;
		space[tail] = tail;
		writef("producer put %d\n", tail);
		syscall_V(mutex);
		syscall_V(full);
	}
}
